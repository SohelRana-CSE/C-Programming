#include <stdlib.h>
int main()
{
    int A[10]= {11,23,5,27,33,1,45,18};
    int S[10];
    int n=9;
    int x =0;
    for(int i=1; i<n-1; i++)
    {

    }
}

